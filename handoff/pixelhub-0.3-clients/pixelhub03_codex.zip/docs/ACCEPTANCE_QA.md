# Kryteria odbioru i testowania — klient NPC v0.1

## Kontrola assetów

- [ ] `python scripts/validate_assets.py` przechodzi bez błędów.
- [ ] 6 identyfikatorów x (3 emocje + 1 awatar) = 24 osobne PNG.
- [ ] Każdy portret ma dokładnie 72×72 px, awatar 48×48 px, plik RGBA.
- [ ] 10 plików UI istnieje, w tym 2 przyciski i 3 ikony.
- [ ] 6 archiwów `.ora` daje się otworzyć w edytorze obsługującym OpenRaster; nie deklaruj Aseprite/PSD.
- [ ] Wszystkie pliki ładują się z rzeczywistej ścieżki publicznej w GitHub Pages bez 404.

## Przegląd w przeglądarce

- [ ] Henryk - 3 emocje; pozostała piątka - 3 emocje; awatary - zgodność tożsamości z portretami.
- [ ] Żaden portret nie jest rozmyty i nie jest deformowany przez skalowanie.
- [ ] Przy długich polskich dialogach tekst się zawija; polskie znaki są poprawne.
- [ ] Panele używają 9-slice, a narożniki nie są rozciągane.
- [ ] Przyciski `Przyjmij` / `Odmów` działają wyłącznie zgodnie z istniejącą mechaniką; w preview są jednoznacznie oznaczone jako demo.
- [ ] Można zamknąć dialog, wrócić do gry i kontynuować pracę; focus / ESC działają zgodnie z obecną konwencją.
- [ ] Widok desktop 1920×1080 i 1366×768; mały viewport; różne skale/zoom.
- [ ] Brak zasłaniania ramp i palet przez stałe elementy UI podczas normalnej rozgrywki.
- [ ] Brak ostrzeżeń `console.error` oraz uszkodzonych ścieżek.

## Regresje mechaniczne

- [ ] Istniejące testy gry przechodzą (`npm test`, `npm run build`, inne obecne w projekcie).
- [ ] Wejście i wyjście z dialogu nie zmienia finansów, CMR, palet ani czasu, jeśli gracz nie dokonał realnej akcji.
- [ ] Nie naruszono kolejki pracowników, samochodów, autowysyłek, stref, sortera i zapisu gry 0.3.
- [ ] Nie odtworzono systemu CMR wyjazdowych znanego ze starszej 0.2.

## Materiał do publicznej recenzji

- [ ] Jeden screenshot Henryka w prawdziwym dialogu gry.
- [ ] Jeden screenshot listy klientów/portretów (jeśli taka lista istnieje) lub z trybu dev preview.
- [ ] `PROJECT_STATUS.md` z oznaczeniem `INTEGRATED - ART DRAFT` lub `BLOCKED` (gdy UI brak).
- [ ] Changelog z hashem publikacji i wyjaśnieniem zmian.
- [ ] Publiczny link do gry i repo w raporcie, bez zmyślonych adresów / commitów.
