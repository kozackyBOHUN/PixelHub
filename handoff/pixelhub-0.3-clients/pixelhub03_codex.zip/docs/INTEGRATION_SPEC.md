# Specyfikacja integracyjna: sześciu klientów i okienko dialogu

## A. Mapowanie

| Client ID | Postać | Rola | Kolor / cecha |
|---|---|---|---|
| `henryk` | Henryk | Piekarnia; pilna pomoc i możliwy klient powracający | szare włosy, wąsy, beżowy fartuch |
| `anna` | Anna | Fundacja i przesyłki pomocowe | kucyk, zielona bluza |
| `robert` | Robert | Handel detaliczny / stałe zamówienia | okulary, niebieska koszula |
| `kasia` | Kasia | Sklep z zabawkami | loki, kolorowy sweter |
| `marek` | Marek | Warsztat i części samochodowe | ciemny kombinezon, zarost |
| `wiktor` | Wiktor | Duże kontrakty handlowe | marynarka, elegancka koszula |

Identyfikatory `henryk`, `anna`, `robert`, `kasia`, `marek`, `wiktor` powinny być stabilnymi kluczami. Nazwy organizacji z `manifest.json` to **etykiety robocze**; jeśli 0.3 ma własne kanoniczne nazwy lub dialogi, zachowaj je.

## B. Zasoby i rozmiary

- Portrety: `assets/characters/clients/{id}/{id}_portrait_{neutral|happy|worried}.png` — **72×72 px** źródłowo, RGBA, krawędź alfa 0/255.
- Awatary: `assets/characters/clients/{id}/{id}_avatar.png` — **48×48 px** źródłowo, RGBA.
- Domyślny render ×2: portrety **144×144 CSS px**, awatary **96×96 CSS px**.
- Domyślny filtr: `image-rendering: pixelated`, Canvas `imageSmoothingEnabled = false`; w Pixi zachować nearest.
- Skala w UI powinna być integralna (1× lub 2× lub 3×), żeby uniknąć zniekształceń; dla małych viewportów można przejść na 1×.
- `preview/` to grafiki do przeglądu, nie do gry.

## C. Mapa ścieżek i Vite

Pakiet zawiera ścieżki manifestu zaczynające się od `assets/…` — odpowiadają one URL-om plików pod katalogiem `public/` w projekcie Vite. Uwzględnij `import.meta.env.BASE_URL` przy budowaniu odnośników, szczególnie na GitHub Pages w podścieżce `/PixelHub/`. Nie używaj na sztywno `/assets/...` na publikowanej podstronie. Nie nadpisuj centralnego `public/assets/manifest.json`, ponieważ należy do wcześniejszego systemu grafik.

Pseudokod (dostosuj do faktycznej architektury):

```ts
const allowedEmotions = new Set(['neutral', 'happy', 'worried']);
function resolveClientPortrait(clientId: string, emotion: string) {
  const client = clientManifest.characters[clientId];
  if (!client) return DEFAULT_PORTRAIT;
  const safeEmotion = allowedEmotions.has(emotion) ? emotion : 'neutral';
  const relative = client.portrait[safeEmotion] || client.portrait.neutral;
  return `${import.meta.env.BASE_URL}${relative}`;
}
```

Do not interpret literal English pseudocode as an instruction to translate the game: the game UI remains in **Polish**.

## D. Okienko dialogowe

Kompozycja: portret po lewej, po prawej (1) imię + organizacja, (2) wypowiedź, (3) trzy pola statystyk: palety, termin, wynagrodzenie, (4) przyciski Przyjmij/Odmów. Przyciski muszą działać z **istniejącymi** akcjami gry; jeśli backend kontraktu nie istnieje, w zwykłym trybie nie pokazuj fikcyjnej interakcji, a dodaj tylko narzędzie preview dla developerów.

PNG w `assets/ui/dialogues/` nie mają wpisanych nazw, kwot ani dialogów. Dynamiczne teksty zachowują polskie znaki i ostrość. Użyj modułu 9-slice: proponowana krawędź 8px natywnie dla paneli oraz 6px dla przycisków, ale sprawdź faktyczny sprite; nie rozciągaj narożników. Na telefonie modal ma pozostać czytelny, dostępny klawiaturą, nie nachodzić na przyciski systemowe i dać się zamknąć.

## E. Integracja z mechaniką 0.3

- CMR przyjazdowe istnieją osobno od specjalnych kontraktów fabularnych. **Nie przywracaj starych wyjazdowych CMR z 0.2.**
- Bohaterowie mogą reprezentować zleceniodawców, ale grafika nie narzuca rozmiarów palet, terminów ani nagród.
- Henryk, Anna i pozostali mają mieć możliwość powrotu w kolejnych rundach **dopiero jeśli mechanika faktycznie to wspiera**. Póki nie wspiera, pokaż to w `PROJECT_STATUS.md` jako planowane.
- Nie modyfikuj ekonomii, rund, mechaniki aut, ścieżkowania, zajętości pól, JSON scenariuszy i zapisu tylko po to, by wyświetlić portret.

## F. Zasady jakości

Jest to **wydanie robocze**: PNG są poprawne wymiarowo, ale mimika, krawędzie, kontury i subtelne różnice emocji wymagają jeszcze przeglądu w grze. Szczególnie `worried` może być za mało czytelny. Nie naprawiaj tego automatycznym wygładzaniem lub losowym retuszem bez akceptacji właściciela. W UI można zwiększyć rozmiar lub kontrast panelu, ale nie zmieniać rozpoznawalnej tożsamości postaci.
