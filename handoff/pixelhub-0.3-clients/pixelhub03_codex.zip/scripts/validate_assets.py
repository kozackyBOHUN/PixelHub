#!/usr/bin/env python3
"""Validate PixelHub client art handoff, using Python standard library only."""
from pathlib import Path
from zipfile import ZipFile, is_zipfile
import json, struct, sys

BASE = Path(__file__).resolve().parents[1]
M = json.loads((BASE / 'manifest.json').read_text(encoding='utf-8'))
EXPECTED = ('henryk','anna','robert','kasia','marek','wiktor')
EMOTIONS = ('neutral','happy','worried')
errors = []

def check_png(path, expected_size=None):
    if not path.is_file():
        errors.append(f'MISSING: {path.relative_to(BASE)}')
        return
    data = path.read_bytes()
    if len(data) < 33 or data[:8] != b'\x89PNG\r\n\x1a\n':
        errors.append(f'BAD PNG: {path.relative_to(BASE)}'); return
    width, height, depth, mode = struct.unpack('>IIBB', data[16:26])
    if expected_size and (width,height) != expected_size:
        errors.append(f'BAD SIZE: {path.relative_to(BASE)} {(width,height)} != {expected_size}')
    if mode != 6: errors.append(f'NON-RGBA PNG: {path.relative_to(BASE)}, mode={mode}')
    return width, height

if set(M.get('characters', {})) != set(EXPECTED):
    errors.append('Manifest character IDs differ from expected six')

n=0
for client in EXPECTED:
    item=M.get('characters',{}).get(client,{})
    for emotion in EMOTIONS:
        s=item.get('portrait',{}).get(emotion)
        if not s: errors.append(f'MISSING MANIFEST: {client} / {emotion}');continue
        check_png(BASE / s, (72,72)); n+=1
    s=item.get('avatar')
    if not s: errors.append(f'MISSING AVATAR MANIFEST: {client}')
    else: check_png(BASE / s, (48,48)); n+=1
    ora=BASE/'editable_sources'/f'{client}_portraits_layered.ora'
    if not is_zipfile(ora): errors.append(f'BAD ORA: {ora.name}')
    else:
        with ZipFile(ora) as z:
            if 'stack.xml' not in z.namelist() or 'mimetype' not in z.namelist():
                errors.append(f'BAD ORA STRUCTURE: {ora.name}')
ui=sorted((BASE/'assets/ui/dialogues').glob('*.png'))
if len(ui)!=10: errors.append(f'UI PNG COUNT: {len(ui)} != 10')
for p in ui: check_png(p)
if n!=24: errors.append(f'CHAR PNG COUNT: {n} != 24')
if errors:
    print('\n'.join(errors),file=sys.stderr);sys.exit(1)
print(f'OK: {n} character PNGs, {len(ui)} UI PNGs, {len(EXPECTED)} layered ORA sources')
