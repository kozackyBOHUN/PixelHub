# PixelHub 0.3 - pakiet portretów klientów / wydanie robocze

**Zawartość:** 18 plików 72x72 RGBA (3 emocje x 6 klientów), 6 awatarów 48x48 RGBA, 10 elementów interfejsu (w tym 5 paneli i 2 przyciski 9-slice oraz 3 ikony), 6 plików edytowalnych `.ora` z osobną warstwą mimiki, 2 podglądy oraz manifest.

**Ważne:** ten zestaw wykonano poprzez ręczne ułożenie i techniczną normalizację zaakceptowanych wcześniej koncepcji. Jest to _roboczy zestaw do integracji i oceny_, nie certyfikowany, ręcznie dopracowany końcowy pixel art. Emocje zostały naniesione jako drobne zmiany mimiki na tych samych portretach; wymagają artystycznego odbioru w grze. Warianty 'worried' mogą wyglądać zbyt subtelnie w małej skali.

Wszystkie portrety są PNG RGBA z alfą wyłącznie 0/255. Zapis źródłowy layered OpenRaster `.ora` otwiera się w Krita lub GIMP; nie jest natywnym `.aseprite` ani `.psd`. Można z niego eksportować do PSD w programie graficznym. Nie ingerowano w działającą grę ani repozytorium.

### Integracja

1. Skopiować katalog `assets/` do przestrzeni publicznych zasobów gry (np. `public/assets/`).
2. Odczytywać ścieżki z `manifest.json`.
3. W CSS i Canvas używać **nearest-neighbor**; nie używać wygładzania.
4. Tworzyć napisy i wartości kontraktu dynamicznie w grze; źródłowe przyciski i okna nie mają tekstu.
5. Panele są konstruowane pod **nine-slice**. Domyślny margines `8 px` dla elementów panelowych; dla małych przycisków można stosować margines `6 px`.
6. Portrety wyświetlać standardowo w skali x2 (144x144), awatary x2 (96x96); dostosowanie do mniejszego viewportu wyłącznie z integer scaling.
7. Przed produkcyjną integracją sprawdzić tożsamość bohaterów, ekspresję 3 emocji, brak obcięć i kontrast na tle gry; zaakceptować po podglądzie z rzeczywistej wersji 0.3.

### Struktura
- `assets/characters/clients/<imię>/` - portrety oraz awatar.
- `assets/ui/dialogues/` - elementy paneli i przycisków.
- `editable_sources/` - edytowalne, warstwowe pliki OpenRaster.
- `preview/` - plansze podglądowe, **nie** zasoby do ładowania przez grę.

### Nowe instrukcje przekazania
- **Najpierw przeczytaj `START_HERE_CODEX.md`.**
- Szczegółowy kontrakt: `docs/INTEGRATION_SPEC.md`.
- Odbiór i testy: `docs/ACCEPTANCE_QA.md`.
- Walidacja paczki: `python scripts/validate_assets.py` (bez dodatkowych bibliotek).
