# PIXELHUB 0.3 — KLIENCI / START HERE CODEX

**Zadanie:** Zintegruj zaakceptowane koncepcje sześciu klientów PixelHub 0.3 z rzeczywiście aktualną wersją gry, przetestuj i opublikuj działający build. Ta paczka zawiera **robocze assety do integracji i oceny w grze**, nie zatwierdzone finalne ilustracje produkcyjne.

## 0. Wstęp: źródło prawdy

- Repozytorium: https://github.com/kozackyBOHUN/PixelHub
- Nie zakładaj, że `main` lub pliki 0.2 opisują aktualną wersję 0.3. Najpierw rozpoznaj katalog roboczy, lokalne gałęzie, nieopublikowane commity i działający build 0.3.
- Nie nadpisuj zmian innych agentów; nie używaj `git push --force`. Nie cofaj istniejących funkcji, scenariuszy i UI 0.3.
- Jeżeli w projekcie istnieje już system NPC / klientów / dialogów / kontraktów, **wykorzystaj go zamiast budować równoległy**.
- Nie zmieniaj mechaniki gry, ekonomii, CMR wysyłkowych, zapisów, postępu fabuły ani bilansu 30 rund tylko w celu podpięcia grafiki.

## 1. Materiały otrzymane w tej paczce

- `assets/characters/clients/<id>/`: sześciu klientów (henryk, anna, robert, kasia, marek, wiktor); 3 portrety emocji 72×72 i awatar 48×48 na osobę — łącznie **24 PNG RGBA**.
- `assets/ui/dialogues/`: **10 PNG** (5 elementów panelowych 9-slice, 2 przyciski 9-slice, 3 ikony).
- `manifest.json`: ścieżki i logiczne identyfikatory, nazwy firm **robocze**.
- `editable_sources/`: **6 plików `.ora`** (OpenRaster, warstwy emocji; nie Aseprite/PSD).
- `preview/`: wzornik postaci i mockup dialogu Henryka. **Nie importować podglądów jako sprite'ów**.
- `scripts/validate_assets.py`: automatyczna kontrola ilości i wymiarów plików.
- `docs/INTEGRATION_SPEC.md` i `docs/ACCEPTANCE_QA.md`: zasady techniczne i kryteria odbioru.

## 2. Kolejność prac

1. **Audyt:** potwierdź bieżącą wersję i system ekranu dialogów, klientów, kontraktów, ścieżek assetów, kamery oraz zapisu.
2. **Walidacja paczki:** uruchom `python scripts/validate_assets.py` w jej katalogu. Sprawdź zgodność 24 portretów/awatarów i 10 elementów UI z manifestem.
3. **Instalacja:** skopiuj folder `assets/characters/clients/` do `public/assets/characters/clients/` i folder `assets/ui/dialogues/` do `public/assets/ui/dialogues/`. Umieść kopię `manifest.json` jako `public/assets/characters/clients/client-characters.manifest.json`, bez nadpisywania głównego `public/assets/manifest.json` czy `catalog.json` silnika grafiki.
4. **Integracja:** zarejestruj 6 identyfikatorów klientów i ścieżki grafik w istniejącej architekturze. Dodaj ładowanie portretu według `clientId + emotion` oraz awatara. Zapewnij bezpieczny fallback na neutralny portret i placeholder.
5. **UI:** podepnij panel z portretem po lewej, dynamicznym imieniem/nazwą organizacji, treścią, liczbą palet, terminem i zapłatą oraz przyciskami „Przyjmij” i „Odmów”. Nie koduj treści wypowiedzi na PNG; użyj istniejących danych zadania. Nie dodawaj fikcyjnych nagród ani przycisków bez realnego działania.
6. **Powiązanie:** podłącz ekspresje do istniejących stanów (`neutral`, `happy`, `worried`), bez tworzenia nowego silnika narracji. Jeśli 0.3 nie ma jeszcze niezbędnego eventu, przygotuj **dev preview** i opisz brak, zamiast wprowadzać nowe zasady fabuły jako pewne.
7. **Testy:** zrealizuj kryteria `docs/ACCEPTANCE_QA.md`; sprawdź build i uruchomienie w prawdziwej przeglądarce.
8. **Publikacja:** po PASS testów commit + push + aktualizacja GitHub Pages i dokumentacji projektu; zweryfikuj publiczną stronę. Nie deklaruj sukcesu bez weryfikacji linków.

## 3. Co musi być dostępne innym agentom

- Gra online pokazująca nowe portrety i dialogi.
- Repo z implementacją, assetami i plikami `PROJECT_STATUS.md`, `GRAPHICS_SPEC.md`, `CHANGELOG.md` (jeśli istnieją — aktualizuj, nie duplikuj).
- Publiczny screenshot rzeczywistego dialogu z Henrykiem oraz grid 6 portretów w skali natywnej i ×2.
- W dokumentacji wskazanie „roboczy art v0.1; emocje do artystycznej kontroli; gotowość techniczna nie równa się finalnemu approval”.

## 4. Raport końcowy wymagany od Codexa

Podaj: 1) adres gry, 2) hash i gałąź commita, 3) raport 34 PNG i wymiarów, 4) wyniki testów, 5) screenshoty z **działającej** gry, 6) listę wdrożonych ekranów/zdarzeń, 7) brakujące elementy fabuły oraz 8) status publikacji.

**Nie zmieniaj zatwierdzonej tożsamości sześciu postaci.** Nie przedstawiaj ilustracji jako finalnie zatwierdzonych sprite'ów. Zadanie zakończone dopiero po faktycznej, zweryfikowanej publikacji.
